module.exports = {
    ML_HOST: 'ussouthcentral.services.azureml.net',
    ML_PATH: '/workspaces/2be93aaa39be437784ae987ff07ae6c7/services/555611ac767c441a80a9405aa5cf38d2/execute?api-version=2.0&format=swagger',
    ML_TOKEN: 'Bearer C96t5Gi+/d3RkoldtD31VE5a6LKtYSPhLe7uofJN59Gn4yeAmdw4AaZuUmQ/xE87R7HY0UCFaW5udACrjit1kw==',
    DB_CONNECTION_URL: 'mongodb://h4cker:phre4ker@ds115015-a0.mlab.com:15015,ds115015-a1.mlab.com:15015/winninghack?replicaSet=rs-ds115015',
    VIDEOS_COLLECTION_ID: 'videos',
    SERIES_COLLECTION_ID: 'series',
    USER_ID: ""
};
