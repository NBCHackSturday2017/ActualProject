var mongoClient = require('mongodb').MongoClient;
var https = require('https');
var querystring = require('querystring');

var DB_CONNECTION_URL = 'mongodb://h4cker:phre4ker@ds115015-a0.mlab.com:15015,ds115015-a1.mlab.com:15015/winninghack?replicaSet=rs-ds115015';
var COLLECTION_ID = "series";
var USER_ID = "";

var showsSuggestedByUserId = {};
var showsForUser = {};

//showId, first and lsat VideoId, and mediumDescription
function getShowForShowName(showName) {
    return new Promise(function(resolve, reject) {
        mongoClient.connect(DB_CONNECTION_URL, function(err, db) {
            if (err) reject(err);
            db.collection(COLLECTION_ID).findOne({"sortTitleLower": showName.toLowerCase()}, function(err, result) {
                if (err) reject(err);
                if (result == null) reject(err);
                resolve(result);
                db.close();
            });
        });
    });
}

module.exports = { getShow: getShowForShowName };