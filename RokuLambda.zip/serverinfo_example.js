exports.host = "127.0.0.1"; //IP Address to talk to your local nodejs server. (Check on https://www.ipify.org/)
exports.port = 1234; //Port to talk to your local nodejs server.
exports.pass = 'password'; // Secure password to access your local nodejs server.
exports.appId = null; //replace this with your app ID to make use of APP_ID verification

