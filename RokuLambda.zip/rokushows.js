// This keeps a list of Roku shows and their 'first available' video (episode) id's.
// Format: "spoken show name": "<videoId>"
shows = {
    "the magicians": "3532110",
    "suits":"3546324",
    "playing house":"2883041",
    "wynonna earp":"3556779",
    "life of kylie":"3560919",
    "shooter":"3562557",
    "the arrangement":"3475555"
};
module.exports = shows;
