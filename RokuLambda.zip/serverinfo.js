exports.host = "rimesmedia.ngrok.io"; //IP Address to talk to your local nodejs server. (Check on https://www.ipify.org/)
exports.port = 80; //Port to talk to your local nodejs server.
exports.pass = 'h4cker-phre4ker'; // Secure password to access your local nodejs server.
exports.appId = null; //replace this with your app ID to make use of APP_ID verification

